#!/sbin/sh
mv /system/priv-app/com.amazon.firehomestarter/com.amazon.firehomestarter.apk /system/priv-app/com.amazon.firehomestarter/com.amazon.firehomestarter.apk.bkp
mv /system/priv-app/com.amazon.tv.launcher/com.amazon.tv.launcher.apk /system/priv-app/com.amazon.tv.launcher/com.amazon.tv.launcher.apk.bkp

